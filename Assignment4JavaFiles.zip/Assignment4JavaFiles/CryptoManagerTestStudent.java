/*
 * Class: CMSC203
 * Instructor: Professor Gary Thai
 * Description: This class deals with encryption and decryption for both the Caesar and the Bellaso methods.
 * Due: 10/20/2025
 * Platform/compiler: Intellij
 * I pledge that I have completed the programming  assignment independently.
 *  I have not copied the code from a student or any source.
 *  I have not given my code to any student.
 *  Print your Name here: Ishan Ruttala
 */


import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CryptoManagerTestStudent {

    @Test
    public void testStringInBounds() {
        assertTrue(CryptoManager.isStringInBounds("SANDWORM"));
        assertTrue(CryptoManager.isStringInBounds("GALAXY"));
        assertTrue(CryptoManager.isStringInBounds("UNIVERSE"));
        assertFalse(CryptoManager.isStringInBounds("sandworm")); // lowercase not allowed
        assertFalse(CryptoManager.isStringInBounds("{UNIVERSE}")); // outside upper range
    }

    @Test
    public void testEncryptCaesar() {
        assertEquals("VDQGZRUP", CryptoManager.caesarEncryption("SANDWORM", 3));
        assertEquals("JDOD[\\", CryptoManager.caesarEncryption("GALAXY", 3));
        assertEquals("XQLYHUVH", CryptoManager.caesarEncryption("UNIVERSE", 3));
    }

    @Test
    public void testDecryptCaesar() {
        assertEquals("SANDWORM", CryptoManager.caesarDecryption("VDQGZRUP", 3));
        assertEquals("GALAXY", CryptoManager.caesarDecryption("JDOD[\\", 3));
        assertEquals("UNIVERSE", CryptoManager.caesarDecryption("XQLYHUVH", 3));
    }

    @Test
    public void testEncryptBellaso() {
        assertEquals("ZBZE/(]R", CryptoManager.bellasoEncryption("SANDWORM", "GALAXYKEY"));
        assertEquals("ZQMD],", CryptoManager.bellasoEncryption("GALAXY", "SPACE"));
        assertEquals("*\\R,PW,Z", CryptoManager.bellasoEncryption("UNIVERSE", "UNIVKEY"));
    }

    @Test
    public void testDecryptBellaso() {
        assertEquals("SANDWORM", CryptoManager.bellasoDecryption("ZBZE/(]R", "GALAXYKEY"));
        assertEquals("GALAXY", CryptoManager.bellasoDecryption("ZQMD],", "SPACE"));
        assertEquals("UNIVERSE", CryptoManager.bellasoDecryption("*\\R,PW,Z", "UNIVKEY"));
    }
}
