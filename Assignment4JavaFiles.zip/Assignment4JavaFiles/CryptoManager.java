/*
 * Class: CMSC203
 * Instructor: Professor Gary Thai
 * Description: This class deals with encryption and decryption for both the Caesar and the Bellaso methods.
 * Due: 10/20/2025
 * Platform/compiler: Intellij
 * I pledge that I have completed the programming  assignment independently.
 *  I have not copied the code from a student or any source.
 *  I have not given my code to any student.
 *  Print your Name here: Ishan Ruttala
 */

public class CryptoManager {

	private static final char LOWER_RANGE = ' ';
	private static final char UPPER_RANGE = '_';

	/**
	 * This method determines if a string is within the allowable bounds of ASCII codes
	 * according to the LOWER_RANGE and UPPER_RANGE characters
	 * @param plainText a string to be encrypted, if it is within the allowable bounds
	 * @return true if all characters are within the allowable bounds, false if any character is outside
	 */
	public static boolean isStringInBounds(String plainText)
	{
		for (int i = 0; i < plainText.length(); i++) //Loops through each character
		{
			char c = plainText.charAt(i);
			if (c < LOWER_RANGE || c > UPPER_RANGE) //Checks just to see if its within the bounds or not
			{
				return false; //If out of bounds, return false
			}
		}
		return true; //If within bounds, return true;
	}

	/**
	 * Encrypts a string according to the Caesar Cipher. The integer key specifies an offset
	 * and each character in plainText is replaced by the character "offset" away from it
	 * @param plainText an uppercase string to be encrypted.
	 * @param key an integer that specifies the offset of each character
	 * @return the encrypted string
	 */
	public static String caesarEncryption(String plainText, int key)
	{
		if (!isStringInBounds(plainText)) //Checks if the text is within the set range
		{
			return "The selected string is not in bounds, Try again."; //Returns this if not
		}

		StringBuilder encrypted = new StringBuilder(); //StringBuilder for the final result
		int range = UPPER_RANGE - LOWER_RANGE + 1; //This is for the total max range for the ASCII

		for (int i = 0; i < plainText.length(); i++) //Another loop for each character
		{
			char c = plainText.charAt(i); //Gets the current character
			int shifted = c + key; //Character gets shifted by the key

			while (shifted > UPPER_RANGE) //If the shifted is above the upperbound, start wrapping!
			{
				shifted -= range; //Keeps subtracting until its within the acceptable bounds
			}
			while (shifted < LOWER_RANGE) //This time if the shifted is below the lower bound, start wrapping!
			{
				shifted += range; //Keeps adding until its within the acceptable bounds
			}

			encrypted.append((char) shifted); //Shifted character is then appended (I think that's the correct term)
		}

		return encrypted.toString(); //Return the final encrypted string!!!
	}

	/**
	 * Encrypts a string according the Bellaso Cipher. Each character in plainText is offset
	 * according to the ASCII value of the corresponding character in bellasoStr, which is repeated
	 * to correspond to the length of plainText
	 * @param plainText an uppercase string to be encrypted.
	 * @param bellasoStr an uppercase string that specifies the offsets, character by character.
	 * @return the encrypted string
	 */
	public static String bellasoEncryption(String plainText, String bellasoStr)
	{
		StringBuilder encrypted = new StringBuilder(); //StringBuilder for the final result
		int range = UPPER_RANGE - LOWER_RANGE + 1; //This is for the total max range for the ASCII

		for (int i = 0; i < plainText.length(); i++) //Another loop for each character
		{
			char c = plainText.charAt(i); //Gets the current character
			char k = bellasoStr.charAt(i % bellasoStr.length()); //Repeats the key if its shorter than the actual text
			int shifted = c + k; //This is for shifting a character based on its ASCII value

			while (shifted > UPPER_RANGE) //If the shifted is above the upperbound, start wrapping!
			{
				shifted -= range; //Keeps subtracting until its within the acceptable bounds
			}

			encrypted.append((char) shifted); //Shifted character is then appended (still hoping thats the correct term)
		}

		return encrypted.toString(); //Return the final encrypted string!!!
	}


	/**
	 * Decrypts a string according to the Caesar Cipher. The integer key specifies an offset
	 * and each character in encryptedText is replaced by the character "offset" characters before it.
	 * This is the inverse of the encryptCaesar method.
	 * @param encryptedText an encrypted string to be decrypted.
	 * @param key an integer that specifies the offset of each character
	 * @return the plain text string
	 */
	public static String caesarDecryption(String cipherText, int key)
	{
		if (!isStringInBounds(cipherText)) //Checks if the already encrypted string was within bounds
		{
			return "The selected string is not in bounds, Try again.";
		}

		StringBuilder decrypted = new StringBuilder(); //StringBuilder for the final result
		int range = UPPER_RANGE - LOWER_RANGE + 1;

		for (int i = 0; i < cipherText.length(); i++) //Another loop for each character
		{
			char c = cipherText.charAt(i); //Gets the encrypted character at that point
			int shifted = c - key; //Gets shifted back based on the key

			while (shifted > UPPER_RANGE) //If the shifted is above the upperbound, start wrapping!
			{
				shifted -= range; //Keeps subtracting until its within the acceptable bounds
			}
			while (shifted < LOWER_RANGE) //This time if the shifted is below the lower bound, start wrapping!
			{
				shifted += range; //Keeps adding until its within the acceptable bounds
			}

			decrypted.append((char) shifted); //Shifted character is then appended (I'm confirming its the correct term)
		}

		return decrypted.toString(); //Returns the final decrypted string!!!
	}

	/**
	 * Decrypts a string according the Bellaso Cipher. Each character in encryptedText is replaced by
	 * the character corresponding to the character in bellasoStr, which is repeated
	 * to correspond to the length of plainText. This is the inverse of the encryptBellaso method.
	 * @param encryptedText an uppercase string to be encrypted.
	 * @param bellasoStr an uppercase string that specifies the offsets, character by character.
	 * @return the decrypted string
	 */
	public static String bellasoDecryption(String encryptedText, String bellasoStr)
	{
		StringBuilder decrypted = new StringBuilder(); //StringBuilder for the final result
		int range = UPPER_RANGE - LOWER_RANGE + 1;

		for (int i = 0; i < encryptedText.length(); i++) //Another loop for each character
		{
			char c = encryptedText.charAt(i);
			char k = bellasoStr.charAt(i % bellasoStr.length());
			int shifted = c - k;

			while (shifted < LOWER_RANGE)
			{
				shifted += range;
			}

			decrypted.append((char) shifted);
		}
		return decrypted.toString();
	}
}