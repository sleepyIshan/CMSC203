/*
 * Class: CMSC203
 * Instructor: Professor Gary Thai
 * Description: This class is the main class and asks the user for their inputs and creates a new Patient object, and 3 Procedure Objects.
 * Due: 10/03/2025
 * Platform/compiler: Intellij
 * I pledge that I have completed the programming
 * assignment independently. I have not copied the code
 * from a student or any source. I have not given my code
 * to any student.
   Print your Name here: Ishan Ruttala
*/

import java.util.Scanner;

public class PatientDriverApp
{
    //Method to display the patient and their information
    public static void displayPatient(Patient patient)
    {
        System.out.println("\n" + patient.toString());
    }

    //Method to display the procedure and its information like name, practitioner and appointment date.
    public static void displayProcedure(Procedure procedure)
    {
        System.out.println(procedure.toString());
    }

    //Method to calculate the total charges of all the procedures (variable name self-explanatory)
    public static double calculateTotalCharges(Procedure proc1, Procedure proc2, Procedure proc3)
    {
        return proc1.getChargesOfProcedure() + proc2.getChargesOfProcedure() + proc3.getChargesOfProcedure();
    }
    //Main method
    public static void main(String[] args) {

        //Import scanner library
        Scanner input = new Scanner(System.in);

        //Ask for patient information
        System.out.print("Enter First Name: ");
        String firstName = input.nextLine();

        System.out.print("Enter Middle Name: ");
        String middleName = input.nextLine();

        System.out.print("Enter Last Name: ");
        String lastName = input.nextLine();

        System.out.print("Enter Street Name: ");
        String streetName = input.nextLine();

        System.out.print("Enter City: ");
        String city = input.nextLine();

        System.out.print("Enter State: ");
        String state = input.nextLine();

        System.out.print("Enter ZIP Code: ");
        String zipCode  = input.nextLine();

        System.out.print("Enter Phone Number: ");
        String phoneNumber = input.nextLine();

        System.out.print("Enter Emergency Contact Name: ");
        String ECName = input.nextLine();

        System.out.print("Enter Emergency Contact Phone: ");
        String ECPhone = input.nextLine();

        //Creating a new patient person with all their information that was added earlier
        Patient patient = new Patient(firstName, middleName, lastName, streetName, city, state, zipCode, phoneNumber, ECName, ECPhone);

        //Creating procedure 1 (With a no ARG constructor)
        Procedure procedure1 = new Procedure();
        procedure1.setNameOfProcedure("X-Ray Scan");
        procedure1.setDateOfProcedure("11/25/2025");
        procedure1.setNameOfPractitioner("Dr. Kenobi");
        procedure1.setChargesOfProcedure(3354.22);

        //Creating procedure 2 (Parametrized constructor with only procedure name and date)
        Procedure procedure2 = new Procedure("MRI Scan", "12/13/2025");
        procedure2.setNameOfPractitioner("Dr. Skywalker");
        procedure2.setChargesOfProcedure(4365.44);

        //Creating procedure 3 (Parametrized constructor with all information)
        Procedure procedure3 = new Procedure("Blood Test", "12/19/2025", "Dr. Vader", 5445.44);

        //Displaying all collected information in order
        displayPatient(patient);
        displayProcedure(procedure1);
        displayProcedure(procedure2);
        displayProcedure(procedure3);

        //Printing out the total cost of the 3 procedures
        double totalCost = calculateTotalCharges(procedure1, procedure2, procedure3);

        //Formatting stuff
        System.out.printf("\nTotal Charges: $%,.2f\n", totalCost);

        //Developer name/details and date
        System.out.println("\nThis program was developed by a student: Ishan Ruttala <10/03/2025>");
    }
}
