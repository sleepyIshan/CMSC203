/*
 * Class: CMSC203
 * Instructor: Professor Gary Thai
 * Description: This class sets and formats the information about the patient
 * Due: 10/03/2025
 * Platform/compiler: Intellij
 * I pledge that I have completed the programming
 * assignment independently. I have not copied the code
 * from a student or any source. I have not given my code
 * to any student.
   Print your Name here: Ishan Ruttala
*/

public class Patient {

    //Attributes (I split them up so it's much easier to read instead of having a hundred things on one line)
    private String firstName, middleName, lastName;
    private String streetAddress, city, state, ZIPCode;
    private String phoneNumber;
    private String nameOfEC, phoneOfEC;

    //No ARG Constructor
    public Patient() {
    }

    //Parametrized Constructor for Patient first, middle and last name
    public Patient(String firstName, String middleName, String lastName) {
        this.firstName = firstName;
        this.middleName = middleName;
        this.lastName = lastName;
    }

    //Parametrized Constructor for all attributes
    public Patient(String firstName, String middleName, String lastName, String streetAddress, String city, String state, String ZIPCode, String phoneNumber, String nameOfEC, String phoneOfEC) {
        this.firstName = firstName;
        this.middleName = middleName;
        this.lastName = lastName;
        this.streetAddress = streetAddress;
        this.city = city;
        this.state = state;
        this.ZIPCode = ZIPCode;
        this.phoneNumber = phoneNumber;
        this.nameOfEC = nameOfEC;
        this.phoneOfEC = phoneOfEC;
    }
    //Getters and Setters
    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public String getMiddleName() {
        return middleName;
    }
    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }
    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    public String getStreetAddress() {
        return streetAddress;
    }
    public void setStreetAddress(String streetAddress) {
        this.streetAddress = streetAddress;
    }
    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }
    public String getState() {
        return state;
    }
    public void setState(String state) {
        this.state = state;
    }
    public String getZIPCode() {
        return ZIPCode;
    }
    public void setZIPCode(String ZIPCode) {
        this.ZIPCode = ZIPCode;
    }
    public String getPhoneNumber() {
        return phoneNumber;
    }
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    public String getNameOfEC() {
        return nameOfEC;
    }
    public void setNameOfEC(String nameOfEC) {
        this.nameOfEC = nameOfEC;
    }
    public String getPhoneOfEC() {
        return phoneOfEC;
    }
    public void setPhoneOfEC(String phoneOfEC) {
        this.phoneOfEC = phoneOfEC;
    }

    //Method to construct the full name of the patient (asks for name segments individually in the PatientDriverApp class)
    public String buildFullName() {
        return firstName + " " + middleName + " " + lastName;
    }

    //Method to construct the full address of the patient (asks for address segments individually in the PatientDriverApp class)
    public String buildAddress() {
        return streetAddress + " " + city + " " + state + " " + ZIPCode;
    }

    //Method to construct the full emergency contact for the patient (asks for the name and phone number individually in the PatientDriverApp class)
    public String buildEmergencyContact() {
        return nameOfEC + " " + phoneOfEC;
    }

    //toString method to put together the patient's full information
    @Override
    public String toString() {
        return "Patient info:\n" + "\tName: " + buildFullName() + "\n" + "\tAddress: " + buildAddress() + "\n" + "\tEmergencyContact: " + buildEmergencyContact();
    }
}
