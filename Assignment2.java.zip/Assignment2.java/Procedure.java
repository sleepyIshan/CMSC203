/*
 * Class: CMSC203
 * Instructor: Professor Gary Thai
 * Description: This class sets and formats the information about the procedure
 * Due: 10/03/2025
 * Platform/compiler: Intellij
 * I pledge that I have completed the programming
 * assignment independently. I have not copied the code
 * from a student or any source. I have not given my code
 * to any student.
   Print your Name here: Ishan Ruttala
*/

public class Procedure
{
    private String nameOfProcedure;
    private String dateOfProcedure;
    private String nameOfPractitioner;
    private double chargesOfProcedure;

    public Procedure() {
    }
    public Procedure(String nameOfProcedure, String dateOfProcedure) {
        this.nameOfProcedure = nameOfProcedure;
        this.dateOfProcedure = dateOfProcedure;
    }
    public Procedure(String nameOfProcedure, String dateOfProcedure, String nameOfPractitioner, double chargesOfProcedure) {
        this.nameOfProcedure = nameOfProcedure;
        this.dateOfProcedure = dateOfProcedure;
        this.nameOfPractitioner = nameOfPractitioner;
        this.chargesOfProcedure = chargesOfProcedure;
    }
    public String getNameOfProcedure() {
        return nameOfProcedure;
    }
    public void setNameOfProcedure(String nameOfProcedure) {
        this.nameOfProcedure = nameOfProcedure;
    }
    public String getDateOfProcedure() {
        return dateOfProcedure;
    }
    public void setDateOfProcedure(String dateOfProcedure) {
        this.dateOfProcedure = dateOfProcedure;
    }
    public String getNameOfPractitioner() {
        return nameOfPractitioner;
    }
    public void setNameOfPractitioner(String nameOfPractitioner) {
        this.nameOfPractitioner = nameOfPractitioner;
    }
    public double getChargesOfProcedure() {
        return chargesOfProcedure;
    }
    public void setChargesOfProcedure(double chargesOfProcedure) {
        this.chargesOfProcedure = chargesOfProcedure;
    }
    @Override
    public String toString() {
        return "\nProcedure: " + nameOfProcedure + "\n" + "\tProcedureDate=" + dateOfProcedure + "\n" + "\tPractitioner=" + nameOfPractitioner + "\n" + "\tCharge = $" + chargesOfProcedure;
    }
}
